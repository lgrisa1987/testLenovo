"use strict"

/* 1) Create a class called Person with the following conditions. */
class Person {

    /* 2) Create the following constructors: */


    /* • A constructor with default values. */
    /* constructor(name = '', age = 0, dni, sex = 'M', weight = 0, height = 0) {
        this.name = name;
        this.age = age;
        this.dni = '12987339';
        this.sex = sex;
        this.weight = weight;
        this.height = height;
    } */


    /* • A constructor with name, age and sex as parameters (other values by default). */
    /*  constructor(name, age, sex, weight = 0, height = 0) {
         this.name = name;
         this.age = age;
         this.dni = '12987339';
         this.sex = sex;
         this.weight = weight;
         this.height = height;
     } */


    /* • A constructor with all attributes received as parameters. default values for name/age/sex/weight/height*/
    constructor(name, age, sex, weight, height) {
        this.name = name;
        this.age = age;
        /*  this.dni = dni; */
        this.sex = sex;
        this.weight = weight;
        this.height = height;
    }

    /* 3) ----------------------- Create the following methods: -----------------------------*/

    calculateIMC() {
        var IMC = this.weight / Math.pow(this.height, 2);
        if (IMC < 20) {
            console.log(`${this.name} is underweight`);
            return -1;
        } else if (IMC >= 20 && IMC <= 25) {
            console.log(`${this.name} has ideal weight`);
            return 0;
        } else {
            console.log(`${this.name} is overweight`);
            return 1;
        }
    }
    isAdult() {
        return this.age >= 18 ? (1, console.log(`${this.name} is an adult`)) : (0, console.log(`${this.name} is not an adult`));
    }
    toString() {
        console.log(`Name: ${this.name}\n Age: ${this.age}\n DNI: ${this.dni}\n Sex: ${this.sex}\n Weight: ${this.weight}\n Height: ${this.height}`);
        return `${this.name} ${this.age} ${this.dni} ${this.sex} ${this.weight}\n ${this.height}`;
    }

    /* getters & setters */

    get createDNI() {
        return this.dni;
    }
    set createDNI(length) {
        var num1 = Math.pow(10, length - 1);
        var num2 = Math.random() * 9;

        this.dni = Math.floor(num1 + num2 * num1);
    }
    get newName() {
        return this.name;
    }
    set newName(newName) {
        this.name = newName;
    }
    get newAge() {
        return this.age;
    }
    set newAge(newAge) {
        this.age = newAge;
    }
    get newSex() {
        return this.sex;
    }
    set newSex(newSex) {
        this.sex = newSex;
    }
    get newWeight() {
        return this.weight;
    }
    set newWeight(newWeight) {
        this.weight = newWeight;
    }
    get newHeight() {
        return this.height;
    }
    set newHeight(newHeight) {
        this.height = newHeight;
    }
}

/* 4) ----------------  Create a runnable class that executes the following: -----------------------------*/

const person1 = ['John', 30, 'M', 85, 1.9];
const person2 = ['Jane', 45, 'F'];

/* Object 1 */
var John = new Person(person1[0], person1[1], person1[2], person1[3], person1[4]);
John.calculateIMC();
John.isAdult();
John.createDNI = 8;
John.toString();
console.log('---------------------------------- \n');

/* Object 2 */
var Jane = new Person(person2[0], person2[1], person2[2]);
Jane.newWeight = 60;
Jane.newHeight = 1.6;
Jane.calculateIMC();
Jane.isAdult();
Jane.createDNI = 8;
Jane.toString();
console.log('---------------------------------- \n');

/* Object 2 */
var Mike = new Person();
Mike.newName = "Mike";
Mike.newAge = 16;
Mike.newSex = "F";
Mike.createDNI = 8;
Mike.newWeight = 85;
Mike.newHeight = 1.7;
Mike.calculateIMC();
Mike.isAdult();
Mike.toString();