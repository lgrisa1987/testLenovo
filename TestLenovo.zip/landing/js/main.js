window.addEventListener('load', () => {

    /* Constantes */
    const check = document.querySelector('.check'),
        headerNav = document.querySelector('.header__nav'),
        productNavList = document.querySelector('.product__nav-list'),
        productNavLink = document.querySelectorAll('.product__nav-link'),
        wrapperContainer = document.querySelector('.wrapper__container');

    var navProducts = ["2in1", "homelaptops", "thinkpadlaptops", "desktops", "monitors", "accessories", "clearance", "outlet"];


    /* Navegación */
    window.addEventListener('resize', () => {
        var w = window.innerWidth;

        if (w > 900) {
            check.checked = false;
            removeClass(headerNav, 'open');
            removeClass(productNavList, 'expand');
            document.body.style.cssText = "overflow: auto;";
        }
    });

    check.addEventListener('change', () => {
        if (check.checked == true) {
            document.body.style.cssText = "overflow: hidden; padding-right: 0";
            addClass(headerNav, 'open');
            addClass(productNavList, 'expand');
        } else {
            removeClass(headerNav, 'open');
            removeClass(productNavList, 'expand');
            setTimeout(() => {
                document.body.style.cssText = "overflow: auto;";
            }, 800);

        }
    })





    for (var i = 0; i < productNavLink.length; i++) {

        /* CARGA DE IMÁGENES NAVEGACIÓN */
        createElement(navProducts[i], productNavLink[i]);

        productNavLink[i].onclick = function () {
            for (var i = 0; i < 8; i++) {
                removeClass(productNavLink[i], 'active');
            }
            this.classList.add("active");
        };
    }
    wrapperContainer.style.display = "block";

});

/* Funciones */

function addClass(elem, clase) {
    elem.classList.add(clase);
}

function removeClass(elem, clase) {
    elem.classList.remove(clase);
}

function createElement(param, param2) {
    var img = document.createElement('img');
    img.setAttribute('src', './img/' + param + '.png');
    img.setAttribute('class', 'product__nav-image');
    img.setAttribute('alt', param.charAt(0).toUpperCase() + param.slice(1));
    param2.insertBefore(img, param2.childNodes[0]);
}